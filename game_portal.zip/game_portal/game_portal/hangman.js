const hangmanWords = [{ word: 'ПОРТАЛ', hint: 'Место, где собраны игры' }, { word: 'БРАУЗЕР', hint: 'Программа для сайтов' }, { word: 'ЗМЕЙКА', hint: 'Игра, где растёт хвост' }, { word: 'КЛАВИША', hint: 'Нажимают на клавиатуре' }, { word: 'МОНЕТА', hint: 'Игровая валюта' }];
let hangmanWord, hangmanUsed, hangmanFails;
function newHangman() {
  const item = hangmanWords[Math.floor(Math.random() * hangmanWords.length)];
  hangmanWord = item.word; hangmanUsed = new Set(); hangmanFails = 0;
  document.getElementById('hangman-hint').textContent = `Подсказка: ${item.hint}`;
  document.getElementById('hangman-status').textContent = 'Ошибок: 0/7';
  const letters = document.getElementById('hangman-letters'); letters.replaceChildren();
  [...'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ'].forEach((letter) => {
    const button = document.createElement('button'); button.textContent = letter; button.onclick = () => guessHangman(letter); letters.appendChild(button);
  });
  drawHangmanWord();
}
function drawHangmanWord() { document.getElementById('hangman-word').textContent = [...hangmanWord].map((letter) => hangmanUsed.has(letter) ? letter : '＿').join(' '); }
function guessHangman(letter) {
  if (!hangmanWord || hangmanFails >= 7 || [...hangmanWord].every((l) => hangmanUsed.has(l))) return;
  hangmanUsed.add(letter);
  const button = [...document.querySelectorAll('#hangman-letters button')].find((el) => el.textContent === letter);
  if (button) button.disabled = true;
  if (!hangmanWord.includes(letter)) hangmanFails += 1;
  drawHangmanWord();
  if ([...hangmanWord].every((l) => hangmanUsed.has(l))) { document.getElementById('hangman-status').textContent = 'Угадано! +30 монет.'; addGlobalCoins(30); }
  else if (hangmanFails >= 7) document.getElementById('hangman-status').textContent = `Попытки закончились. Было слово: ${hangmanWord}.`;
  else document.getElementById('hangman-status').textContent = `Ошибок: ${hangmanFails}/7`;
}
window.addEventListener('DOMContentLoaded', newHangman);
