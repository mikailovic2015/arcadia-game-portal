let targetScore = 0;
function hitTarget() {
    targetScore++;
    let btn = document.getElementById('target-btn');
    let scoreEl = document.getElementById('target-score');
    if (scoreEl) scoreEl.innerText = targetScore;
    addGlobalCoins(5);
    if (btn) {
        btn.style.marginTop = Math.floor(Math.random() * 100) + 'px';
        btn.style.marginLeft = Math.floor(Math.random() * 100) + 'px';
    }
}
