function flipCoin(choice) {
    let betInput = document.getElementById('coin-bet');
    let bet = parseInt(betInput ? betInput.value : 0);

    if (!bet || bet <= 0 || globalCoins < bet) {
        alert('Недостаточно монет или неверная ставка!');
        return;
    }

    globalCoins -= bet;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();

    let result = Math.random() < 0.5 ? 'heads' : 'tails';
    let resText = result === 'heads' ? '🦅 Орел' : '🪙 Решка';
    let el = document.getElementById('coin-result');

    if (choice === result) {
        let win = bet * 2;
        addGlobalCoins(win);
        if (el) el.innerText = `🎉 Выпал ${resText}! Вы выиграли ${win} монет!`;
    } else {
        if (el) el.innerText = `💸 Выпал ${resText}! Вы проиграли ${bet} монет.`;
    }
}
