const wordsList = [
    { hint: "🍌 🐒 🌴", word: "банан" },
    { hint: "🚗 ⛽ 🛣️", word: "машина" },
    { hint: "💻 ⌨️ 🖱️", word: "компьютер" },
    { hint: "🍕 🧀 🍅", word: "пицца" }
];
let currentWordIdx = 0;

function loadWord() {
    let item = wordsList[currentWordIdx];
    let h = document.getElementById('word-hint');
    if (h) h.innerText = item.hint;
}

function checkWord() {
    let inp = document.getElementById('word-input');
    if (!inp) return;
    let val = inp.value.toLowerCase().trim();
    if (val === wordsList[currentWordIdx].word) {
        addGlobalCoins(60);
        alert('Правильно! +60 монет');
        currentWordIdx = (currentWordIdx + 1) % wordsList.length;
        inp.value = '';
        loadWord();
    } else {
        alert('Неверное слово!');
    }
}
window.addEventListener('DOMContentLoaded', loadWord);
