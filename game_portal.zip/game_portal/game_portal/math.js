let mathA = 0, mathB = 0, mathAns = 0;

function nextMath() {
    mathA = Math.floor(Math.random() * 20) + 1;
    mathB = Math.floor(Math.random() * 20) + 1;
    mathAns = mathA + mathB;
    let q = document.getElementById('math-question');
    if (q) q.innerText = `${mathA} + ${mathB} = ?`;
}

function checkMath() {
    let inp = document.getElementById('math-input');
    if (!inp) return;
    let val = parseInt(inp.value);
    if (val === mathAns) {
        addGlobalCoins(25);
        inp.value = '';
        nextMath();
    } else {
        alert('Неправильно! Попробуй еще раз.');
    }
}
window.addEventListener('DOMContentLoaded', nextMath);
