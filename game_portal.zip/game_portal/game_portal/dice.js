function rollDice(userNum) {
    let betInput = document.getElementById('dice-bet');
    let bet = parseInt(betInput ? betInput.value : 0);

    if (!bet || bet <= 0 || globalCoins < bet) {
        alert('Недостаточно монет или неверная ставка!');
        return;
    }

    globalCoins -= bet;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();

    let dice = Math.floor(Math.random() * 6) + 1;
    let el = document.getElementById('dice-result');

    if (userNum === dice) {
        let win = bet * 5;
        addGlobalCoins(win);
        if (el) el.innerText = `🎲 Выпало ${dice}! ПОБЕДА! +${win} монет! 🎉`;
    } else {
        if (el) el.innerText = `🎲 Выпало ${dice}! Вы ставили на ${userNum}. Проиграно ${bet} монет. 💸`;
    }
}
