let guessNumber = 1 + Math.floor(Math.random() * 100);
let guessAttempts = 7;
function resetGuess() {
  guessNumber = 1 + Math.floor(Math.random() * 100);
  guessAttempts = 7;
  const input = document.getElementById('guess-input');
  if (input) input.value = '';
  const status = document.getElementById('guess-status');
  if (status) status.textContent = 'Новое число загадано. У тебя 7 попыток.';
}
function checkGuess() {
  const input = document.getElementById('guess-input');
  const value = Number(input?.value);
  const status = document.getElementById('guess-status');
  if (!Number.isInteger(value) || value < 1 || value > 100) {
    if (status) status.textContent = 'Введи целое число от 1 до 100.';
    return;
  }
  if (guessAttempts <= 0) return;
  guessAttempts -= 1;
  if (value === guessNumber) {
    if (status) status.textContent = `Точно! Осталось попыток: ${guessAttempts}. +${10 + guessAttempts * 5} монет.`;
    addGlobalCoins(10 + guessAttempts * 5);
    guessAttempts = 0;
  } else if (guessAttempts === 0) {
    if (status) status.textContent = `Попытки закончились. Было загадано ${guessNumber}. Нажми «Заново».`;
  } else if (status) {
    status.textContent = `${value < guessNumber ? 'Больше' : 'Меньше'}! Осталось попыток: ${guessAttempts}.`;
  }
}
