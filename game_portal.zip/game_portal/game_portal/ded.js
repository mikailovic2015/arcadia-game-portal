let farts = parseInt(localStorage.getItem('farts')) || 0;

function saveDed() {
    localStorage.setItem('farts', farts);
    document.getElementById('fart-count').innerText = farts;
    if (farts > 50) document.getElementById('fart-lvl').innerText = "🔥 ВЗРЫВ";
    else if (farts > 20) document.getElementById('fart-lvl').innerText = "💨 ГРОМКИЙ";
}

function fart(e) {
    farts++;
    saveDed();
    const cloud = document.createElement('div');
    cloud.className = 'fart-cloud';
    cloud.innerText = '💨';
    const rect = document.getElementById('ded-clicker').getBoundingClientRect();
    cloud.style.left = (e.clientX - rect.left - 10) + 'px';
    cloud.style.top = (e.clientY - rect.top - 10) + 'px';
    document.getElementById('ded-clicker').appendChild(cloud);
    setTimeout(() => cloud.remove(), 800);
}
saveDed();
