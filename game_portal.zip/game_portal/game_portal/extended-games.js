let guessSecret = 0, guessLeft = 7;
function resetGuess() {
  guessSecret = Math.floor(Math.random() * 100) + 1;
  guessLeft = 7;
  const input = document.getElementById('guess-input');
  const status = document.getElementById('guess-status');
  if (input) input.value = '';
  if (input) input.disabled = false;
  if (status) status.textContent = 'У тебя 7 попыток.';
}
function checkGuess() {
  const input = document.getElementById('guess-input');
  const status = document.getElementById('guess-status');
  const value = Number(input?.value);
  if (!input || !status || !Number.isInteger(value) || value < 1 || value > 100) { if (status) status.textContent = 'Введи целое число от 1 до 100.'; return; }
  guessLeft -= 1;
  if (value === guessSecret) {
    addGlobalCoins(35);
    status.textContent = 'Верно! +35 монет. Нажми «Заново» для новой партии.';
    input.disabled = true;
  } else if (guessLeft <= 0) {
    status.textContent = `Попытки закончились. Было загадано ${guessSecret}. Нажми «Заново».`;
    input.disabled = true;
  } else status.textContent = `${value < guessSecret ? 'Больше' : 'Меньше'}. Осталось попыток: ${guessLeft}.`;
}

let balancePosition = 50, balanceTimer = 0, balanceActive = false;
function renderBalance() {
  const ball = document.getElementById('balance-ball');
  if (ball) ball.style.left = `${balancePosition}%`;
}
function startBalance() {
  clearInterval(balanceTimer);
  balancePosition = 50;
  balanceActive = true;
  renderBalance();
  const status = document.getElementById('balance-status');
  if (status) status.textContent = 'Удерживай шар на платформе 10 секунд.';
  let seconds = 0;
  balanceTimer = window.setInterval(() => {
    balancePosition += (Math.random() - 0.5) * 16;
    renderBalance();
    seconds += 1;
    if (balancePosition < 4 || balancePosition > 96) {
      clearInterval(balanceTimer); balanceActive = false;
      if (status) status.textContent = 'Шар упал. Попробуй ещё раз.';
    } else if (seconds >= 10) {
      clearInterval(balanceTimer); balanceActive = false; addGlobalCoins(40);
      if (status) status.textContent = 'Баланс удержан! +40 монет.';
    }
  }, 1000);
}
function balanceTilt(direction) {
  if (!balanceActive) return;
  balancePosition = Math.max(2, Math.min(98, balancePosition + direction * 12));
  renderBalance();
}

let minerOre = Number(localStorage.getItem('portalMinerOre')) || 0;
let minerLevel = Number(localStorage.getItem('portalMinerLevel')) || 1;
function updateMiner() {
  const ore = document.getElementById('miner-ore'), level = document.getElementById('miner-level'), cost = document.getElementById('miner-cost');
  if (ore) ore.textContent = String(minerOre);
  if (level) level.textContent = String(minerLevel);
  if (cost) cost.textContent = String(minerLevel * 40);
  localStorage.setItem('portalMinerOre', String(minerOre));
  localStorage.setItem('portalMinerLevel', String(minerLevel));
}
function mineOre() {
  const found = Math.random() < 0.72;
  const status = document.getElementById('miner-status');
  if (found) {
    const amount = Math.floor(Math.random() * 5) + minerLevel;
    minerOre += amount; addGlobalCoins(amount * 3);
    if (status) status.textContent = `Нашёл ${amount} руды. +${amount * 3} монет.`;
  } else if (status) status.textContent = 'Камень пустой. Попробуй ещё раз.';
  const rock = document.getElementById('miner-rock');
  if (rock) { rock.textContent = found ? '💎' : '🪨'; setTimeout(() => { rock.textContent = '🪨'; }, 450); }
  updateMiner();
}
function upgradePickaxe() {
  const cost = minerLevel * 40, status = document.getElementById('miner-status');
  if (minerOre < cost) { if (status) status.textContent = `Нужно ${cost} руды для улучшения.`; return; }
  minerOre -= cost; minerLevel += 1;
  if (status) status.textContent = `Кирка улучшена до уровня ${minerLevel}.`;
  updateMiner();
}

let tttCells = Array(9).fill(''), tttTurn = 'X', tttFinished = false;
function tttResult(cells) {
  for (const [a,b,c] of [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]) if (cells[a] && cells[a] === cells[b] && cells[a] === cells[c]) return cells[a];
  return cells.every(Boolean) ? 'draw' : '';
}
function renderTTT() {
  document.querySelectorAll('#ttt-board .cell').forEach((cell, i) => { cell.textContent = tttCells[i]; });
}
function resetTTT() {
  tttCells = Array(9).fill(''); tttTurn = 'X'; tttFinished = false; renderTTT();
  const status = document.getElementById('ttt-status');
  if (status) status.textContent = 'Ход: X';
}
function tttMove(index) {
  if (tttFinished || tttCells[index]) return;
  tttCells[index] = tttTurn;
  const result = tttResult(tttCells);
  if (result) {
    tttFinished = true;
    if (result === 'X') addGlobalCoins(20);
    const status = document.getElementById('ttt-status');
    if (status) status.textContent = result === 'draw' ? 'Ничья. Начни новую партию.' : `Победил ${result}${result === 'X' ? ' — +20 монет!' : ''}`;
  } else {
    tttTurn = tttTurn === 'X' ? 'O' : 'X';
    const status = document.getElementById('ttt-status');
    if (status) status.textContent = `Ход: ${tttTurn}`;
  }
  renderTTT();
}

window.addEventListener('DOMContentLoaded', () => { resetGuess(); updateMiner(); resetTTT(); });
