let puzzleTiles = [];
function resetPuzzle() {
  puzzleTiles = [1,2,3,4,5,6,7,8,0];
  for (let i = 0; i < 45; i++) {
    const empty = puzzleTiles.indexOf(0), neighbors = [empty - 3, empty + 3, ...(empty % 3 ? [empty - 1] : []), ...(empty % 3 < 2 ? [empty + 1] : [])].filter((n) => n >= 0 && n < 9);
    const next = neighbors[Math.floor(Math.random() * neighbors.length)]; [puzzleTiles[empty], puzzleTiles[next]] = [puzzleTiles[next], puzzleTiles[empty]];
  }
  renderPuzzle();
}
function renderPuzzle() {
  const grid = document.getElementById('puzzle-grid'); grid.replaceChildren();
  puzzleTiles.forEach((value, index) => {
    const button = document.createElement('button'); button.textContent = value ? String(value) : ''; if (!value) button.classList.add('empty');
    button.disabled = !value; button.onclick = () => movePuzzle(index); grid.appendChild(button);
  });
}
function movePuzzle(index) {
  const empty = puzzleTiles.indexOf(0);
  const adjacent = Math.abs(index - empty) === 3 || (Math.floor(index / 3) === Math.floor(empty / 3) && Math.abs(index - empty) === 1);
  if (!adjacent) return;
  [puzzleTiles[index], puzzleTiles[empty]] = [puzzleTiles[empty], puzzleTiles[index]]; renderPuzzle();
  if (puzzleTiles.join(',') === '1,2,3,4,5,6,7,8,0') { document.getElementById('puzzle-status').textContent = 'Готово! +45 монет.'; addGlobalCoins(45); }
}
window.addEventListener('DOMContentLoaded', resetPuzzle);
