let board = ["","","","","","","","",""], ticActive = true;
function makeMove(i) {
    if (board[i] === "" && ticActive) {
        board[i] = "X"; renderTic();
        if (!checkWin("X")) setTimeout(botMove, 200);
    }
}
function botMove() {
    let empty = board.map((v, i) => v === "" ? i : null).filter(v => v !== null);
    if (empty.length > 0 && ticActive) {
        board[empty[Math.floor(Math.random() * empty.length)]] = "O";
        renderTic(); checkWin("O");
    }
}
function checkWin(p) {
    const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for (let w of wins) {
        if (w.every(i => board[i] === p)) {
            document.getElementById("tic-status").innerText = p === "X" ? "🎉 Победа!" : "🤖 Бот выиграл!";
            ticActive = false; return true;
        }
    }
    if (!board.includes("")) { document.getElementById("tic-status").innerText = "🤝 Ничья!"; ticActive = false; return true; }
    return false;
}
function renderTic() { document.querySelectorAll('#tic-grid .cell').forEach((v, i) => v.innerText = board[i]); }
function resetTic() { board = ["","","","","","","","",""]; ticActive = true; document.getElementById("tic-status").innerText = "Твой ход (X)"; renderTic(); }
