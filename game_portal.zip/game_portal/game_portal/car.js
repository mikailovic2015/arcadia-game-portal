const cCanvas = document.getElementById("carCanvas"), cCtx = cCanvas.getContext("2d");
let myCar = { x: 30, y: 180, w: 50, h: 45 }, enemyCar = { x: 135, y: -60, w: 50, h: 45, speed: 4 }, carScore = 0;
function moveCar(dir) { myCar.x = (dir === 'LEFT') ? 30 : 135; }
function carLoop() {
    cCtx.fillStyle = "#334155"; cCtx.fillRect(0, 0, 220, 240);
    cCtx.fillStyle = "#ffffff"; cCtx.fillRect(107, 0, 6, 240);
    cCtx.fillStyle = "#38bdf8"; cCtx.fillRect(myCar.x, myCar.y, myCar.w, myCar.h);
    cCtx.fillStyle = "#ef4444"; cCtx.fillRect(enemyCar.x, enemyCar.y, enemyCar.w, enemyCar.h);
    enemyCar.y += enemyCar.speed;
    if (myCar.x < enemyCar.x + enemyCar.w && myCar.x + myCar.w > enemyCar.x && myCar.y < enemyCar.y + enemyCar.h && myCar.y + myCar.h > enemyCar.y) {
        carScore = 0; enemyCar.y = -60; enemyCar.speed = 4;
    }
    if (enemyCar.y > 240) {
        enemyCar.y = -60; enemyCar.x = Math.random() > 0.5 ? 30 : 135;
        carScore += 10; enemyCar.speed += 0.3;
    }
    document.getElementById("car-score").innerText = carScore;
}
setInterval(carLoop, 1000/30);
