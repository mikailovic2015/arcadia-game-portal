const mazeMap = ['S....', '###..', '.....', '####.', '....E'];
let mazePlayer = { x: 0, y: 0 }, mazeFinished = false;
function resetMaze() { mazePlayer = { x: 0, y: 0 }; mazeFinished = false; drawMaze(); }
function drawMaze() {
  const grid = document.getElementById('maze-grid');
  if (!grid) return;
  grid.replaceChildren();
  mazeMap.forEach((row, y) => [...row].forEach((cell, x) => {
    const tile = document.createElement('span'); tile.className = `maze-cell${cell === '#' ? ' wall' : ''}`;
    tile.textContent = mazePlayer.x === x && mazePlayer.y === y ? '🧭' : cell === 'S' ? '🚪' : cell === 'E' ? '🏁' : '';
    grid.appendChild(tile);
  }));
}
function moveMaze(dx, dy) {
  if (mazeFinished) return;
  const x = mazePlayer.x + dx, y = mazePlayer.y + dy;
  if (x < 0 || x >= 5 || y < 0 || y >= 5 || mazeMap[y][x] === '#') return;
  mazePlayer = { x, y }; drawMaze();
  if (mazeMap[y][x] === 'E') {
    mazeFinished = true; addGlobalCoins(40);
    document.getElementById('maze-status').textContent = 'Выход найден! +40 монет. Нажми «Новый лабиринт», чтобы пройти ещё раз.';
  }
}
window.addEventListener('DOMContentLoaded', resetMaze);
