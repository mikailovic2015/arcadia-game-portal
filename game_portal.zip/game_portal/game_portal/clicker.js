let cData = JSON.parse(localStorage.getItem('cData')) || { coins: 0, power: 1, auto: 0, costClick: 10, costAuto: 50 };

function saveClicker() {
    localStorage.setItem('cData', JSON.stringify(cData));
    updateClickerUI();
}

function updateClickerUI() {
    document.getElementById('c-coins').innerText = cData.coins;
    document.getElementById('c-power').innerText = cData.power;
    document.getElementById('c-auto').innerText = cData.auto;
    document.getElementById('c-cost-click').innerText = cData.costClick;
    document.getElementById('c-cost-auto').innerText = cData.costAuto;
}

function clickerHit() {
    cData.coins += cData.power;
    saveClicker();
}

function buyClickerUpgrade(type) {
    if (type === 'click' && cData.coins >= cData.costClick) {
        cData.coins -= cData.costClick;
        cData.power += 1;
        cData.costClick = Math.floor(cData.costClick * 1.5);
    } else if (type === 'auto' && cData.coins >= cData.costAuto) {
        cData.coins -= cData.costAuto;
        cData.auto += 1;
        cData.costAuto = Math.floor(cData.costAuto * 1.6);
    }
    saveClicker();
}

setInterval(() => {
    if (cData.auto > 0) {
        cData.coins += cData.auto;
        saveClicker();
    }
}, 1000);

updateClickerUI();
