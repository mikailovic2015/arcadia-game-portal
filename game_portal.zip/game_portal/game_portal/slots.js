function spinSlots() {
    let betInput = document.getElementById('slots-bet');
    let bet = parseInt(betInput ? betInput.value : 0);

    if (!bet || bet <= 0 || globalCoins < bet) {
        alert('Недостаточно монет или неверная ставка!');
        return;
    }

    globalCoins -= bet;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();

    const items = ['🍎', '🍋', '🍒', '7️⃣', '💎'];
    let a = items[Math.floor(Math.random() * items.length)];
    let b = items[Math.floor(Math.random() * items.length)];
    let c = items[Math.floor(Math.random() * items.length)];

    let disp = document.getElementById('slots-display');
    if (disp) disp.innerText = `${a} | ${b} | ${c}`;

    if (a === b && b === c) {
        let win = bet * 10;
        addGlobalCoins(win);
        alert(`🎰 ДЖЕКПОТ! Вы выиграли ${win} монет! 🎉`);
    } else if (a === b || b === c || a === c) {
        let win = Math.floor(bet * 1.5);
        addGlobalCoins(win);
        alert(`✨ Две совпали! Вы выиграли ${win} монет!`);
    } else {
        // Проигрыш (ставка уже списана)
    }
}
