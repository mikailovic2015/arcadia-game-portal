function playRSP(player) {
    const opts = ['✊', '✂️', '📄'];
    let bot = opts[Math.floor(Math.random() * 3)];
    let res = document.getElementById('rsp-status');

    if (player === bot) {
        if (res) res.innerText = `🤝 Ничья! Бот выставил ${bot}`;
    } else if (
        (player === '✊' && bot === '✂️') ||
        (player === '✂️' && bot === '📄') ||
        (player === '📄' && bot === '✊')
    ) {
        if (res) res.innerText = `🎉 Победа! Бот выставил ${bot}. +20 монет!`;
        addGlobalCoins(20);
    } else {
        if (res) res.innerText = `🤖 Поражение! Бот выставил ${bot}.`;
    }
}
