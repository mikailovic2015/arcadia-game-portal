function playRoulette(color) {
    let betInput = document.getElementById('roulette-bet');
    let bet = parseInt(betInput ? betInput.value : 0);

    if (!bet || bet <= 0) {
        alert('Введите корректную ставку!');
        return;
    }
    if (globalCoins < bet) {
        alert('❌ Недостаточно монет для ставки!');
        return;
    }

    // Списываем ставку
    globalCoins -= bet;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();

    const colors = ['🔴', '⚫', '🔴', '⚫', '🔴', '⚫', '🟢'];
    let result = colors[Math.floor(Math.random() * colors.length)];
    let status = document.getElementById('roulette-status');

    let win = false;
    let multiplier = 0;

    if (color === 'red' && result === '🔴') { win = true; multiplier = 2; }
    if (color === 'black' && result === '⚫') { win = true; multiplier = 2; }
    if (color === 'green' && result === '🟢') { win = true; multiplier = 14; }

    if (win) {
        let prize = bet * multiplier;
        addGlobalCoins(prize);
        if (status) status.innerText = `🎰 Выпало ${result}! Вы выиграли ${prize} монет! 🎉`;
    } else {
        if (status) status.innerText = `🎰 Выпало ${result}! Вы проиграли ${bet} монет. 💸`;
    }
}
