const memoryIcons = ['🐶', '🐱', '🐭', '🦊', '🐼', '🐸'];
let cards = [], flipped = [], matched = 0, memoryMoves = 0, memoryLocked = false;
function resetMemory() {
  cards = [...memoryIcons, ...memoryIcons];
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  flipped = []; matched = 0; memoryMoves = 0; memoryLocked = false;
  const moves = document.getElementById('memory-moves');
  const pairs = document.getElementById('memory-pairs');
  if (moves) moves.textContent = '0';
  if (pairs) pairs.textContent = '0';
  const grid = document.getElementById('memory-grid');
  if (!grid) return;
  grid.replaceChildren();
  cards.forEach((icon) => {
    const card = document.createElement('button');
    card.type = 'button'; card.className = 'mem-card'; card.dataset.icon = icon;
    card.textContent = '？'; card.setAttribute('aria-label', 'Закрытая карточка');
    card.onclick = () => flipCard(card);
    grid.appendChild(card);
  });
}
function flipCard(card) {
  if (memoryLocked || card.classList.contains('open') || card.classList.contains('matched')) return;
  card.textContent = card.dataset.icon || '';
  card.classList.add('open'); card.setAttribute('aria-label', card.dataset.icon || 'Карточка');
  flipped.push(card);
  if (flipped.length < 2) return;
  memoryMoves += 1;
  const moves = document.getElementById('memory-moves');
  if (moves) moves.textContent = String(memoryMoves);
  if (flipped[0].dataset.icon === flipped[1].dataset.icon) {
    flipped.forEach((item) => item.classList.add('matched'));
    flipped = []; matched += 1;
    const pairs = document.getElementById('memory-pairs');
    if (pairs) pairs.textContent = String(matched);
    addGlobalCoins(15);
    if (matched === memoryIcons.length) {
      addGlobalCoins(40);
      const status = document.getElementById('memory-meta');
      if (status) status.insertAdjacentText('beforeend', ' · Всё найдено! Бонус +40');
    }
    return;
  }
  memoryLocked = true;
  setTimeout(() => {
    flipped.forEach((item) => { item.textContent = '？'; item.classList.remove('open'); item.setAttribute('aria-label', 'Закрытая карточка'); });
    flipped = []; memoryLocked = false;
  }, 650);
}
window.addEventListener('DOMContentLoaded', resetMemory);
