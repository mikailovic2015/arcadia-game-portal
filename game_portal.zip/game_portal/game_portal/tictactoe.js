let tttBoard = Array(9).fill(''), tttTurn = 'X', tttActive = true;
const tttWins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
function renderTTT() { document.querySelectorAll('#ttt-board .cell').forEach((cell, i) => { cell.textContent = tttBoard[i]; }); }
function resetTTT() { tttBoard = Array(9).fill(''); tttTurn = 'X'; tttActive = true; document.getElementById('ttt-status').textContent = 'Ход: X'; renderTTT(); }
function tttMove(i) {
  if (!tttActive || tttBoard[i]) return;
  tttBoard[i] = tttTurn; renderTTT();
  const won = tttWins.some((line) => line.every((cell) => tttBoard[cell] === tttTurn));
  if (won) { tttActive = false; document.getElementById('ttt-status').textContent = `Победили ${tttTurn}!`; addGlobalCoins(20); return; }
  if (tttBoard.every(Boolean)) { tttActive = false; document.getElementById('ttt-status').textContent = 'Ничья!'; return; }
  tttTurn = tttTurn === 'X' ? 'O' : 'X'; document.getElementById('ttt-status').textContent = `Ход: ${tttTurn}`;
}
