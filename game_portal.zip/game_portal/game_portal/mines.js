let minesBet = 0, minesActive = false, minesCount = 0;

function startMines() {
    let betInput = document.getElementById('mines-bet');
    minesBet = parseInt(betInput ? betInput.value : 0);

    if (!minesBet || minesBet <= 0 || globalCoins < minesBet) {
        alert('Недостаточно монет!');
        return;
    }

    globalCoins -= minesBet;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();

    minesActive = true;
    minesCount = 0;

    let grid = document.getElementById('mines-grid');
    if (!grid) return;
    grid.innerHTML = '';

    let bombIdx = Math.floor(Math.random() * 9);

    for (let i = 0; i < 9; i++) {
        let btn = document.createElement('button');
        btn.className = 'cell';
        btn.innerText = '❓';
        btn.onclick = () => {
            if (!minesActive) return;
            if (i === bombIdx) {
                btn.innerText = '💥';
                minesActive = false;
                alert(`💥 ВЗРЫВ! Вы проиграли ${minesBet} монет.`);
            } else {
                btn.innerText = '💎';
                btn.disabled = true;
                minesCount++;
                let currentWin = Math.floor(minesBet * (1 + minesCount * 0.4));
                let status = document.getElementById('mines-status');
                if (status) status.innerText = `Открыто: ${minesCount} | Забрать: ${currentWin} монет`;
            }
        };
        grid.appendChild(btn);
    }
}

function takeMinesWin() {
    if (!minesActive || minesCount === 0) return;
    minesActive = false;
    let win = Math.floor(minesBet * (1 + minesCount * 0.4));
    addGlobalCoins(win);
    alert(`💰 Вы забрали ${win} монет!`);
}
