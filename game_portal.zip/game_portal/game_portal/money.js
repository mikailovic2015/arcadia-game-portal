let mData = JSON.parse(localStorage.getItem('mData')) || { balance: 0, perSwipe: 100, autoSwipe: 0, costClick: 500, costAuto: 1000 };

function saveMoney() {
    localStorage.setItem('mData', JSON.stringify(mData));
    updateMoneyUI();
}

function updateMoneyUI() {
    document.getElementById('m-balance').innerText = mData.balance;
    document.getElementById('m-cost-click').innerText = mData.costClick;
    document.getElementById('m-cost-auto').innerText = mData.costAuto;
}

function throwMoney() {
    mData.balance += mData.perSwipe;
    saveMoney();

    const mArea = document.getElementById('money-area');
    const bill = document.createElement('div');
    bill.className = 'money-bill';
    bill.innerText = '💵';

    let startX = mArea.clientWidth / 2 - 15;
    let startYPos = mArea.clientHeight - 50;
    bill.style.left = startX + 'px';
    bill.style.top = startYPos + 'px';
    mArea.appendChild(bill);

    let vx = (Math.random() - 0.5) * 6;
    let vy = -(6 + Math.random() * 4);
    let posX = startX, posY = startYPos;

    let anim = setInterval(() => {
        posX += vx; posY += vy; vy += 0.4;
        bill.style.left = posX + 'px'; bill.style.top = posY + 'px';
        if (posY >= mArea.clientHeight - 30) {
            clearInterval(anim);
            setTimeout(() => bill.remove(), 1000);
        }
    }, 1000 / 60);
}

function buyMoneyUpgrade(type) {
    if (type === 'click' && mData.balance >= mData.costClick) {
        mData.balance -= mData.costClick;
        mData.perSwipe += 200;
        mData.costClick = Math.floor(mData.costClick * 1.8);
    } else if (type === 'auto' && mData.balance >= mData.costAuto) {
        mData.balance -= mData.costAuto;
        mData.autoSwipe += 1;
        mData.costAuto = Math.floor(mData.costAuto * 2);
    }
    saveMoney();
}

// Свайпы
const mArea = document.getElementById('money-area');
let startY = 0, isSwiping = false;
mArea.addEventListener('touchstart', e => { isSwiping = true; startY = e.touches[0].clientY; });
mArea.addEventListener('touchmove', e => {
    if (!isSwiping) return;
    if (startY - e.touches[0].clientY > 25) { throwMoney(); startY = e.touches[0].clientY; }
});
mArea.addEventListener('touchend', () => isSwiping = false);

// Авто-доход каждые секунды
setInterval(() => {
    if (mData.autoSwipe > 0) {
        mData.balance += mData.autoSwipe * mData.perSwipe;
        saveMoney();
    }
}, 1000);

updateMoneyUI();
