let chairData = JSON.parse(localStorage.getItem('chairData')) || { lvl: 1, hp: 10, maxHp: 10 };
const chairs = [{ name: "Табурет", icon: "🪑", hp: 10 }, { name: "Офисный стул", icon: "💺", hp: 25 }, { name: "Трон", icon: "💎", hp: 60 }];

function saveChair() {
    localStorage.setItem('chairData', JSON.stringify(chairData));
    updateChairUI();
}

function updateChairUI() {
    let c = chairs[Math.min(chairData.lvl - 1, chairs.length - 1)];
    document.getElementById('chair-lvl').innerText = chairData.lvl;
    document.getElementById('chair-name').innerText = c.name;
    document.getElementById('chair-icon').innerText = c.icon;
    document.getElementById('chair-hp').innerText = chairData.hp;
    document.getElementById('chair-max-hp').innerText = chairData.maxHp;
    document.getElementById('hp-fill').style.width = (chairData.hp / chairData.maxHp * 100) + "%";
}

function hitChair() {
    chairData.hp--;
    if (chairData.hp <= 0) {
        chairData.lvl++;
        let c = chairs[Math.min(chairData.lvl - 1, chairs.length - 1)];
        chairData.maxHp = c.hp;
        chairData.hp = chairData.maxHp;
    }
    saveChair();
}
updateChairUI();
