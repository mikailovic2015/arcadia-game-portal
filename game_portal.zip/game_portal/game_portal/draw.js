const pCanvas = document.getElementById("paintCanvas"), pCtx = pCanvas.getContext("2d");
let painting = false, color = "#ef4444";
function setColor(c) { color = c; }
function clearCanvas() { pCtx.clearRect(0, 0, pCanvas.width, pCanvas.height); }
function startDraw(e) { painting = true; draw(e); }
function endDraw() { painting = false; pCtx.beginPath(); }
function draw(e) {
    if (!painting) return;
    let rect = pCanvas.getBoundingClientRect();
    let x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    let y = (e.touches ? e.touches[0].clientY : e.clientY) - rect.top;
    pCtx.lineWidth = 4; pCtx.lineCap = "round"; pCtx.strokeStyle = color;
    pCtx.lineTo(x, y); pCtx.stroke(); pCtx.beginPath(); pCtx.moveTo(x, y);
}
pCanvas.addEventListener("mousedown", startDraw); pCanvas.addEventListener("mouseup", endDraw); pCanvas.addEventListener("mousemove", draw);
pCanvas.addEventListener("touchstart", startDraw); pCanvas.addEventListener("touchend", endDraw); pCanvas.addEventListener("touchmove", draw);
