let balanceX = 50, balanceActive = false, balanceTicks = 0, balanceTimer = null;
function startBalance() {
  clearInterval(balanceTimer); balanceX = 50; balanceTicks = 0; balanceActive = true; drawBalance();
  document.getElementById('balance-status').textContent = 'Удерживай шар на платформе 10 секунд.';
  balanceTimer = setInterval(() => {
    balanceTicks += 1; balanceX += (Math.random() - 0.5) * 8;
    if (balanceX < 0 || balanceX > 100) { balanceActive = false; clearInterval(balanceTimer); document.getElementById('balance-status').textContent = 'Шар скатился! Попробуй ещё раз.'; return; }
    drawBalance();
    if (balanceTicks >= 20) { balanceActive = false; clearInterval(balanceTimer); addGlobalCoins(30); document.getElementById('balance-status').textContent = 'Баланс удержан! +30 монет.'; }
  }, 500);
}
function balanceTilt(direction) { if (!balanceActive) return; balanceX += direction * 8; drawBalance(); }
function drawBalance() { const ball = document.getElementById('balance-ball'); if (ball) ball.style.left = `${Math.max(0, Math.min(100, balanceX))}%`; }
