let wheelTurns = 0;
function playWheel() {
 const prizes=[10,25,50,100,200,0,15], index=Math.floor(Math.random()*prizes.length), prize=prizes[index]; wheelTurns += 1080 + index*360/prizes.length;
 const display=document.getElementById('wheel-display'); display.style.transform=`rotate(${wheelTurns}deg)`;
 setTimeout(()=>{if(prize)addGlobalCoins(prize);document.getElementById('wheel-status').textContent=prize?`Колесо остановилось на ${prize} монетах. Начислено!`:'Банкрот! В этот раз без выигрыша.';},1050);
}
