let bjBet = 0, bjPlayer = 0, bjDealer = 0, bjActive = false;

function startBlackjack() {
    let betInput = document.getElementById('bj-bet');
    bjBet = parseInt(betInput ? betInput.value : 0);

    if (!bjBet || bjBet <= 0 || globalCoins < bjBet) {
        alert('Недостаточно монет или неверная ставка!');
        return;
    }

    globalCoins -= bjBet;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();

    bjPlayer = Math.floor(Math.random() * 10) + 2 + Math.floor(Math.random() * 10) + 2;
    bjDealer = Math.floor(Math.random() * 10) + 2;
    bjActive = true;

    updateBJUI(`Игра началась! Твои очки: ${bjPlayer}`);
}

function bjHit() {
    if (!bjActive) return;
    bjPlayer += Math.floor(Math.random() * 10) + 1;
    if (bjPlayer > 21) {
        bjActive = false;
        updateBJUI(`💥 Перебор (${bjPlayer})! Вы проиграли ${bjBet} монет.`);
    } else {
        updateBJUI(`Вы взяли карту. Очки: ${bjPlayer}`);
    }
}

function bjStand() {
    if (!bjActive) return;
    bjActive = false;
    while (bjDealer < 17) {
        bjDealer += Math.floor(Math.random() * 10) + 1;
    }

    if (bjDealer > 21 || bjPlayer > bjDealer) {
        let win = bjBet * 2;
        addGlobalCoins(win);
        updateBJUI(`🎉 Победа! У дилера ${bjDealer}. Вы выиграли ${win} монет!`);
    } else if (bjPlayer === bjDealer) {
        addGlobalCoins(bjBet);
        updateBJUI(`🤝 Ничья (${bjPlayer} = ${bjDealer}). Ставка возвращена.`);
    } else {
        updateBJUI(`🤖 Дилер выиграл (${bjDealer} против ${bjPlayer}). Проиграно ${bjBet} монет.`);
    }
}

function updateBJUI(msg) {
    let el = document.getElementById('bj-status');
    if (el) el.innerText = msg;
}
