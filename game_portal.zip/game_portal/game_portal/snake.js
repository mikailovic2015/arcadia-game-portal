const sCanvas = document.getElementById("snakeCanvas"), sCtx = sCanvas.getContext("2d");
let snake = [{x: 90, y: 90}], food = {x: 40, y: 40}, dir = "RIGHT", snakeScore = 0;
function setDir(d) {
    if (d==="UP" && dir!=="DOWN") dir="UP"; if (d==="DOWN" && dir!=="UP") dir="DOWN";
    if (d==="LEFT" && dir!=="RIGHT") dir="LEFT"; if (d==="RIGHT" && dir!=="LEFT") dir="RIGHT";
}
function snakeLoop() {
    let head = {...snake[0]};
    if (dir === "UP") head.y -= 10; if (dir === "DOWN") head.y += 10;
    if (dir === "LEFT") head.x -= 10; if (dir === "RIGHT") head.x += 10;

    if (head.x < 0 || head.x >= 180 || head.y < 0 || head.y >= 180 || snake.some(s => s.x === head.x && s.y === head.y)) {
        snake = [{x: 90, y: 90}]; snakeScore = 0; dir = "RIGHT";
    } else {
        snake.unshift(head);
        if (head.x === food.x && head.y === food.y) {
            snakeScore += 10;
            food = {x: Math.floor(Math.random()*18)*10, y: Math.floor(Math.random()*18)*10};
        } else { snake.pop(); }
    }
    document.getElementById("snake-score").innerText = snakeScore;
    sCtx.fillStyle = "#0f172a"; sCtx.fillRect(0, 0, 180, 180);
    sCtx.fillStyle = "#ef4444"; sCtx.fillRect(food.x, food.y, 10, 10);
    sCtx.fillStyle = "#22c55e"; snake.forEach(s => sCtx.fillRect(s.x, s.y, 10, 10));
}
setInterval(snakeLoop, 150);
