(() => {
  const categories = {
    chance: new Set(['roulette', 'bj', 'tower', 'coin', 'dice', 'slots', 'mines', 'wheel', 'slots2']),
    arcade: new Set(['money', 'clicker', 'react', 'flap', 'ded', 'chair', 'car', 'snake', 'jump', 'miner', 'target']),
    puzzle: new Set(['guess', 'memory', 'rsp', 'math', 'word', 'simon', 'draw', 'tic', 'maze', 'tictactoe', 'hangman', 'puzzles', 'balance', 'trivia']),
  };

  const applyFilters = () => {
    const query = document.querySelector('#game-search')?.value.trim().toLocaleLowerCase('ru') || '';
    const category = document.querySelector('.category-btn.active')?.dataset.filter || 'all';
    document.querySelectorAll('.menu-btn').forEach((button) => {
      const game = button.dataset.game;
      const label = button.textContent.trim().toLocaleLowerCase('ru');
      const categoryMatches = category === 'all' || game === 'shop' || categories[category]?.has(game);
      button.hidden = !(categoryMatches && label.includes(query));
    });
  };

  document.querySelector('#game-search')?.addEventListener('input', applyFilters);
  document.querySelectorAll('.category-btn').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelector('.category-btn.active')?.classList.remove('active');
      button.classList.add('active');
      applyFilters();
    });
  });
  applyFilters();
})();
