let globalCoins = Number(localStorage.getItem('globalCoins') ?? 1000);

function addGlobalCoins(amount) {
    let mult = parseInt(localStorage.getItem('coinMultiplier')) || 1;
    globalCoins += amount * mult;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();
}

function updateGlobalUI() {
    let el = document.getElementById('global-coins');
    if (el) el.innerText = globalCoins;
}

function switchGame(gameId, e) {
    document.querySelectorAll('.game-screen').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.menu-btn').forEach(b => b.classList.remove('active'));
    let target = document.getElementById(gameId);
    if (target) target.classList.add('active');
    if (e && e.target) e.target.classList.add('active');
}

window.addEventListener('DOMContentLoaded', () => {
    updateGlobalUI();
    // Применяем сохраненную тему при загрузке
    let savedTheme = localStorage.getItem('portalTheme');
    if (savedTheme === 'neon' || savedTheme === 'gold') {
        document.body.dataset.theme = savedTheme;
    }
});

setInterval(updateGlobalUI, 500);
