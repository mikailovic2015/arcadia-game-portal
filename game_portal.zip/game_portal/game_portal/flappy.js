let flapY = 80;
let flapTimer = null;

function jumpFlap() {
    flapY -= 35;
    if (flapY < 0) flapY = 0;
    updateFlap();
    addGlobalCoins(2);
}

function updateFlap() {
    flapY += 3;
    if (flapY > 150) flapY = 150;
    let bird = document.getElementById('flap-bird');
    if (bird) bird.style.top = flapY + 'px';
}

if (!flapTimer) {
    flapTimer = setInterval(updateFlap, 50);
}
