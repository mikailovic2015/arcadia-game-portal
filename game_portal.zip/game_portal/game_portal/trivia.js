const triviaQuestions = [
  { q:'Сколько будет 7 × 8?', a:['54','56','64','48'], correct:1 },
  { q:'Какая планета ближе всего к Солнцу?', a:['Венера','Марс','Меркурий','Земля'], correct:2 },
  { q:'Сколько сторон у шестиугольника?', a:['5','6','7','8'], correct:1 },
  { q:'Какой океан самый большой?', a:['Атлантический','Индийский','Северный Ледовитый','Тихий'], correct:3 },
  { q:'Сколько минут в двух часах?', a:['100','110','120','140'], correct:2 }
];
let triviaIndex = Math.floor(Math.random() * triviaQuestions.length), triviaAnswered = false;
function renderTrivia() {
 const item=triviaQuestions[triviaIndex], q=document.getElementById('trivia-question'), opts=document.getElementById('trivia-options'); if(!q||!opts)return;
 triviaAnswered=false; q.textContent=item.q; opts.replaceChildren(); item.a.forEach((answer,i)=>{const b=document.createElement('button');b.textContent=answer;b.onclick=()=>answerTrivia(i,b);opts.appendChild(b);}); document.getElementById('trivia-status').textContent='Выбери ответ.';
}
function answerTrivia(i,button) { if(triviaAnswered)return; triviaAnswered=true; const item=triviaQuestions[triviaIndex]; const buttons=[...document.querySelectorAll('#trivia-options button')]; buttons.forEach((b,n)=>b.disabled=true); if(i===item.correct){button.classList.add('success-btn');document.getElementById('trivia-status').textContent='Верно! +40 монет.';addGlobalCoins(40);}else{button.classList.add('choice-red');buttons[item.correct].classList.add('success-btn');document.getElementById('trivia-status').textContent='Не угадал. Попробуй следующий вопрос.';} }
function nextTrivia(){triviaIndex=(triviaIndex+1)%triviaQuestions.length;renderTrivia();}
window.addEventListener('DOMContentLoaded',renderTrivia);
