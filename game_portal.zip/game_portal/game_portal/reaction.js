let reactStartTime, reactTimeout;
function startReactionTest() {
    let box = document.getElementById('react-box');
    if (!box) return;
    box.style.background = '#ef4444';
    box.innerText = 'Жди зеленого...';
    clearTimeout(reactTimeout);
    reactTimeout = setTimeout(() => {
        box.style.background = '#22c55e';
        box.innerText = 'ЖМИ СЕЙЧАС!';
        reactStartTime = Date.now();
    }, Math.random() * 3000 + 1500);
}
function hitReaction() {
    let box = document.getElementById('react-box');
    if (!box) return;
    if (box.style.background === 'rgb(34, 197, 94)') {
        let diff = Date.now() - reactStartTime;
        box.innerText = `${diff} ms! (+50 монет)`;
        box.style.background = '#1e293b';
        addGlobalCoins(50);
    } else if (box.style.background === 'rgb(239, 68, 68)') {
        box.innerText = 'Слишком рано!';
        box.style.background = '#1e293b';
    }
}
