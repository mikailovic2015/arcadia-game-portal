let minerData = { ore: 0, level: 1 };
try { minerData = { ...minerData, ...JSON.parse(localStorage.getItem('minerData') || '{}') }; } catch {}
function updateMiner() {
  const ore = document.getElementById('miner-ore'); if (!ore) return;
  ore.textContent = String(minerData.ore); document.getElementById('miner-level').textContent = String(minerData.level);
  document.getElementById('miner-cost').textContent = String(minerData.level * 40);
}
function mineOre() {
  const gain = minerData.level + Math.floor(Math.random() * minerData.level * 3) + 1;
  minerData.ore += gain; addGlobalCoins(gain);
  document.getElementById('miner-status').textContent = `Ты нашёл ${gain} руды и получил ${gain} монет.`;
  document.getElementById('miner-rock').textContent = ['🪨','💎','🪨','🪙'][Math.floor(Math.random()*4)];
  localStorage.setItem('minerData', JSON.stringify(minerData)); updateMiner();
}
function upgradePickaxe() {
  const cost = minerData.level * 40;
  if (globalCoins < cost) { document.getElementById('miner-status').textContent = `Нужно ещё ${cost - globalCoins} монет.`; return; }
  globalCoins -= cost; localStorage.setItem('globalCoins', String(globalCoins)); updateGlobalUI(); minerData.level++;
  localStorage.setItem('minerData', JSON.stringify(minerData)); document.getElementById('miner-status').textContent = `Кирка улучшена до уровня ${minerData.level}.`; updateMiner();
}
window.addEventListener('DOMContentLoaded', updateMiner);
