let towerBet = 0, towerLevel = 0, towerActive = false;

function startTower() {
    let betInput = document.getElementById('tower-bet');
    towerBet = parseInt(betInput ? betInput.value : 0);

    if (!towerBet || towerBet <= 0 || globalCoins < towerBet) {
        alert('Недостаточно монет!');
        return;
    }

    globalCoins -= towerBet;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();

    towerLevel = 1;
    towerActive = true;
    updateTowerUI(`Этаж 1: Выберите дверь (1 или 2)`);
}

function stepTower(door) {
    if (!towerActive) return;

    let trap = Math.floor(Math.random() * 2) + 1;
    if (door === trap) {
        towerActive = false;
        updateTowerUI(`💥 Ловушка! Вы проиграли ${towerBet} монет на ${towerLevel} этаже.`);
    } else {
        towerLevel++;
        if (towerLevel > 5) {
            towerActive = false;
            let win = towerBet * 5;
            addGlobalCoins(win);
            updateTowerUI(`🏆 ВЕРШИНА! Вы прошли башню и забрали ${win} монет!`);
        } else {
            updateTowerUI(`✅ Верно! Этаж ${towerLevel}. Умножитель: x${towerLevel}`);
        }
    }
}

function takeTowerMoney() {
    if (!towerActive || towerLevel <= 1) return;
    towerActive = false;
    let win = Math.floor(towerBet * (towerLevel - 0.5));
    addGlobalCoins(win);
    updateTowerUI(`💰 Вы забрали выигрыш ${win} монет!`);
}

function updateTowerUI(msg) {
    let el = document.getElementById('tower-status');
    if (el) el.innerText = msg;
}
