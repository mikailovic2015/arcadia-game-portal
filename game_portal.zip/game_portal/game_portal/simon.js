let simonSeq = [], simonUser = [];

function startSimon() {
    simonSeq = [Math.floor(Math.random() * 4)];
    simonUser = [];
    showSimon();
}

function showSimon() {
    let status = document.getElementById('simon-status');
    if (status) status.innerText = 'Запомни! Длина: ' + simonSeq.length;
    
    let i = 0;
    let interval = setInterval(() => {
        if (i >= simonSeq.length) {
            clearInterval(interval);
            if (status) status.innerText = 'Твой ход!';
            return;
        }
        flashCell(simonSeq[i]);
        i++;
    }, 800);
}

function flashCell(id) {
    let cells = document.querySelectorAll('#simon .cell');
    if (cells[id]) {
        cells[id].style.opacity = '0.2';
        setTimeout(() => cells[id].style.opacity = '1', 400);
    }
}

function pressSimon(id) {
    if (simonSeq.length === 0) return;
    flashCell(id);
    simonUser.push(id);

    if (simonUser[simonUser.length - 1] !== simonSeq[simonUser.length - 1]) {
        alert('Ошибка! Игра окончена.');
        simonSeq = [];
        simonUser = [];
        let status = document.getElementById('simon-status');
        if (status) status.innerText = 'Нажми Старт';
        return;
    }

    if (simonUser.length === simonSeq.length) {
        addGlobalCoins(40);
        simonUser = [];
        simonSeq.push(Math.floor(Math.random() * 4));
        setTimeout(showSimon, 800);
    }
}
