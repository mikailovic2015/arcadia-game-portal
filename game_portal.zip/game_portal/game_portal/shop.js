function buyItem(type, cost) {
    // Берём актуальный баланс
    let coins = parseInt(localStorage.getItem('globalCoins')) || 0;

    if (coins < cost) {
        alert('❌ Недостаточно монет!');
        return;
    }

    if (type === 'boost_x2') {
        let currentMultiplier = parseInt(localStorage.getItem('coinMultiplier')) || 1;
        if (currentMultiplier >= 2) {
            alert('У вас уже куплен этот бустер!');
            return;
        }
        coins -= cost;
        localStorage.setItem('coinMultiplier', 2);
        alert('🎉 Куплен бустер x2 на все выигрыши!');
    } else if (type === 'theme_neon') {
        coins -= cost;
        localStorage.setItem('portalTheme', 'neon');
        document.body.dataset.theme = 'neon';
        alert('🎨 Неоновая тема активирована!');
    } else if (type === 'theme_gold') {
        coins -= cost;
        localStorage.setItem('portalTheme', 'gold');
        document.body.dataset.theme = 'gold';
        alert('👑 Золотая тема активирована!');
    }

    // Сохраняем и обновляем UI
    globalCoins = coins;
    localStorage.setItem('globalCoins', globalCoins);
    updateGlobalUI();
}
