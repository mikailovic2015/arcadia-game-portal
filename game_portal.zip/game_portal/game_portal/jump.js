let jumpTarget = 1 + Math.floor(Math.random() * 10);
function playJump() {
  const input = document.getElementById('jump-input');
  const status = document.getElementById('jump-status');
  const guess = Number(input?.value);
  if (!Number.isInteger(guess) || guess < 1 || guess > 10) { status.textContent = 'Выбери целое число от 1 до 10.'; return; }
  if (guess === jumpTarget) {
    status.textContent = 'Идеальный прыжок! +60 монет. Новая дистанция уже загадана.';
    addGlobalCoins(60); jumpTarget = 1 + Math.floor(Math.random() * 10);
  } else {
    status.textContent = `${guess < jumpTarget ? 'Прыгни дальше' : 'Прыгни ближе'} — попробуй ещё раз.`;
  }
}
