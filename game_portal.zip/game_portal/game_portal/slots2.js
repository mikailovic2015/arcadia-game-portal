function playSlots2() {
 const items=['🍒','🍋','🍉','⭐','💎']; const roll=Array.from({length:3},()=>items[Math.floor(Math.random()*items.length)]);
 document.getElementById('slots2-display').textContent=roll.join('　'); const count=roll.filter(x=>x===roll[0]).length; let reward=0,message='Не совпало — попробуй ещё раз.';
 if(count===3){reward=150;message=`Джекпот! Три ${roll[0]} — +150 монет.`;}else if(new Set(roll).size<3){reward=25;message='Совпали два символа — +25 монет.';}
 if(reward)addGlobalCoins(reward); document.getElementById('slots2-status').textContent=message;
}
